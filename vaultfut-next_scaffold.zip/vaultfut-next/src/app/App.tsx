export default function App() {
  return <div>VaultFUT Next 🚀</div>;
}